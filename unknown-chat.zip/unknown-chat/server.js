const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  maxHttpBufferSize: 1e6,
  cors: { origin: true, credentials: false }
});

app.use(express.static(path.join(__dirname, 'public')));

const waiting = new Map(); // socket.id -> preferences
const matches = new Map(); // socket.id -> socket.id
const reports = [];

function onlineCount() {
  return io.engine.clientsCount;
}

function broadcastOnline() {
  io.emit('online-count', onlineCount());
}

function compatible(a, b) {
  const interestA = a.interest || 'any';
  const interestB = b.interest || 'any';
  return interestA === 'any' || interestB === 'any' || interestA === interestB;
}

function findMatch(socket) {
  const pref = waiting.get(socket.id);
  if (!pref) return;

  for (const [candidateId, candidatePref] of waiting.entries()) {
    if (candidateId === socket.id) continue;
    if (!io.sockets.sockets.has(candidateId)) {
      waiting.delete(candidateId);
      continue;
    }
    if (!compatible(pref, candidatePref)) continue;

    const candidate = io.sockets.sockets.get(candidateId);
    waiting.delete(socket.id);
    waiting.delete(candidateId);
    matches.set(socket.id, candidateId);
    matches.set(candidateId, socket.id);

    socket.emit('matched', { peer: 'شخص مجهول' });
    candidate.emit('matched', { peer: 'شخص مجهول' });
    return;
  }
}

io.on('connection', (socket) => {
  broadcastOnline();

  socket.emit('online-count', onlineCount());

  socket.on('find-random', (prefs = {}) => {
    const oldPeer = matches.get(socket.id);
    if (oldPeer) {
      const peer = io.sockets.sockets.get(oldPeer);
      matches.delete(socket.id);
      matches.delete(oldPeer);
      if (peer) peer.emit('partner-left');
    }

    waiting.set(socket.id, {
      interest: typeof prefs.interest === 'string' ? prefs.interest : 'any'
    });
    socket.emit('searching');
    findMatch(socket);
  });

  socket.on('message', (raw) => {
    const peerId = matches.get(socket.id);
    if (!peerId) return;
    const peer = io.sockets.sockets.get(peerId);
    if (!peer) return;

    const text = String(raw || '').trim().slice(0, 1000);
    if (!text) return;
    peer.emit('message', { text, at: Date.now() });
  });

  socket.on('typing', () => {
    const peerId = matches.get(socket.id);
    const peer = peerId && io.sockets.sockets.get(peerId);
    if (peer) peer.emit('typing');
  });

  socket.on('stop-typing', () => {
    const peerId = matches.get(socket.id);
    const peer = peerId && io.sockets.sockets.get(peerId);
    if (peer) peer.emit('stop-typing');
  });

  socket.on('leave-chat', () => {
    waiting.delete(socket.id);
    const peerId = matches.get(socket.id);
    if (peerId) {
      const peer = io.sockets.sockets.get(peerId);
      matches.delete(socket.id);
      matches.delete(peerId);
      if (peer) peer.emit('partner-left');
    }
  });

  socket.on('report', (reason = 'other') => {
    reports.push({ socketId: socket.id, reason: String(reason).slice(0, 100), at: new Date().toISOString() });
    if (reports.length > 1000) reports.shift();
  });

  socket.on('disconnect', () => {
    waiting.delete(socket.id);
    const peerId = matches.get(socket.id);
    if (peerId) {
      const peer = io.sockets.sockets.get(peerId);
      matches.delete(socket.id);
      matches.delete(peerId);
      if (peer) peer.emit('partner-left');
    }
    broadcastOnline();
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Unknown Chat running on http://localhost:${PORT}`);
});
