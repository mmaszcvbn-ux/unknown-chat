const socket = io();

const homeView = document.getElementById('homeView');
const chatView = document.getElementById('chatView');
const randomBtn = document.getElementById('randomBtn');
const onlineCount = document.getElementById('onlineCount');
const messages = document.getElementById('messages');
const composer = document.getElementById('composer');
const input = document.getElementById('messageInput');
const typing = document.getElementById('typing');
const statusText = document.getElementById('statusText');
const toast = document.getElementById('toast');
const reportDialog = document.getElementById('reportDialog');

let currentInterest = 'any';
let typingTimer;

function show(view) {
  homeView.classList.toggle('active', view === 'home');
  chatView.classList.toggle('active', view === 'chat');
}

function notify(text) {
  toast.textContent = text;
  toast.classList.add('show');
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => toast.classList.remove('show'), 2200);
}

function startSearch(interest = currentInterest) {
  currentInterest = interest;
  show('chat');
  statusText.textContent = 'جاري البحث…';
  messages.innerHTML = `<div class="match-card"><div class="mini-logo">⌁</div><h2>جاري البحث…</h2><p>نبحث لك عن شخص مجهول مناسب.</p></div>`;
  socket.emit('find-random', { interest });
}

randomBtn.addEventListener('click', () => startSearch('any'));
document.querySelectorAll('.option').forEach(btn => {
  btn.addEventListener('click', () => startSearch(btn.dataset.interest));
});

document.querySelectorAll('.suggest').forEach(btn => {
  btn.addEventListener('click', () => {
    input.value = btn.textContent.replaceAll('"', '');
    input.focus();
  });
});

socket.on('online-count', count => {
  onlineCount.textContent = Number(count || 0).toLocaleString('ar-IQ');
});

socket.on('searching', () => {
  statusText.textContent = 'جاري البحث…';
});

socket.on('matched', () => {
  statusText.textContent = 'متصل';
  messages.innerHTML = `
    <div class="match-card" id="matchCard">
      <div class="mini-logo">⌁</div>
      <h2>تم العثور على شخص!</h2>
      <p>أنت الآن تتحدث مع شخص مجهول.</p>
      <div class="suggestions">
        <div class="suggest-title">✦ اقتراح للبدء</div>
        <button class="suggest">"ما آخر شيء أسعدك؟"</button>
        <button class="suggest">"ما هي هوايتك؟"</button>
        <button class="suggest">"من أي بلد أنت؟"</button>
      </div>
    </div>`;
  messages.querySelectorAll('.suggest').forEach(btn => {
    btn.addEventListener('click', () => {
      input.value = btn.textContent.replaceAll('"', '');
      input.focus();
    });
  });
  input.focus();
});

socket.on('message', ({ text }) => {
  addMessage(text, 'peer');
});

function addMessage(text, type) {
  const el = document.createElement('div');
  el.className = `message ${type}`;
  el.textContent = text;
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
}

composer.addEventListener('submit', e => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  addMessage(text, 'me');
  socket.emit('message', text);
  input.value = '';
  socket.emit('stop-typing');
});

input.addEventListener('input', () => {
  socket.emit('typing');
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => socket.emit('stop-typing'), 700);
});

socket.on('typing', () => {
  typing.classList.add('show');
});
socket.on('stop-typing', () => typing.classList.remove('show'));

function leaveChat() {
  socket.emit('leave-chat');
  show('home');
  statusText.textContent = 'متصل';
  input.value = '';
}

document.getElementById('backBtn').addEventListener('click', leaveChat);
document.getElementById('endChat').addEventListener('click', leaveChat);

document.getElementById('reportBtn').addEventListener('click', () => reportDialog.showModal());
document.getElementById('closeDialog').addEventListener('click', () => reportDialog.close());
reportDialog.querySelectorAll('[data-reason]').forEach(btn => {
  btn.addEventListener('click', () => {
    socket.emit('report', btn.dataset.reason);
    reportDialog.close();
    notify('تم إرسال البلاغ، شكراً لك.');
  });
});

document.getElementById('menuBtn').addEventListener('click', () => {
  notify('الموقع مجهول ولا يحتاج إلى إنشاء حساب.');
});

window.addEventListener('beforeunload', () => socket.emit('leave-chat'));
